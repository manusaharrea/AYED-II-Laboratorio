#ifndef _LIST_H
#define _LIST_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct _Node * list;
typedef int list_elem;

//constructores 

list empty(void);
//{- crea una lista vacía. -}

list addl(list_elem e, list l);
//{- agrega el elemento e al comienzo de la lista l. -}

//Operaciones

void list_destroy(list l);
//{- Libera memoria en caso que sea necesario. -}

bool is_empty_list(list l);
//{- Devuelve True si l es vacía. -}

list_elem head(list l);
//Pre = !is_empty_list(l)
//{- Devuelve el primer elemento de la lista l -}

list tail (list l);
//Pre = !is_empty_list(l)
//{- Elimina el primer elemento de la lista l -}

list addr (list_elem e, list l);
//{- agrega el elemento e al final de la lista l. -}

int length (list l);
//{- Devuelve la cantidad de elementos de la lista l -}

list concat(list l1, list l2);
//{- Agrega al final de l1 todos los elementos de l2 en el mismo orden.-}

list_elem index (int n, list l);
//{- Devuelve el n-ésimo elemento de la lista l -}
//{- PRE: length(l) > n -}

list take (int n, list l);
//{- Deja en l sólo los primeros n elementos, eliminando el resto -}

list drop (int n, list l);
//{- Elimina los primeros n elementos de l -}

list copy_list(list l);
//{- Copia todos los elementos de l en la nueva lista -}

#endif