#include "list.h"

typedef struct _Node {
    list_elem elem;
    struct _Node *next;    
} Node;

//constructores 

list empty(void){
    list l = NULL;
return l;
}

list addl(list_elem e, list l){
    list p = malloc(sizeof(Node));
    p->elem = e;
    p->next = l;
    l = p;
return l;
}

//operations 

void list_destroy(list l){
    list q, p;
    if (l != NULL){
        p = l;
        while (q->next != NULL){
            p = q;
            q = q->next;
            free(p);
        }
    }
}

bool is_empty_list(list l){
    bool b = (l == empty());
return b;
}

list addr(list_elem e, list l){
   
    Node *q,*p = malloc(sizeof(Node));
    p->elem = e;
    (p->next) = NULL;

    if (l != NULL){
        q = l;
        while(q->next != NULL){
            q = q->next;    
        }
        q->next = p;   
    } else {
        l = p;
    }
return l;
}

list_elem head(list l){
    assert(!is_empty_list(l));
    list_elem elem;
    elem = l->elem;
return elem;
}

list tail (list l){
    assert(!is_empty_list(l));
    list t;
    t = l; //apuntamos al primer nodo 
    free(t); //lo liberamos
return l;
}

int length (list l){
    int resultado = 0;
    list t = NULL;
    t = l;
    while (t->next != NULL){
        t = t->next;
        resultado++;
    }
return resultado;
}

list concat(list l1, list l2){
    list t;
    t = l1;
    while (t->next != NULL){
        t = t->next;
    }
    t->next = l2;   
return l1;
}

list_elem index (int n, list l){
    assert(length(l) > n );

    list_elem elem;
    int contador = 0;
    Node *t;
    t = l;
    while (contador != n ){
        t = t->next;
        contador++; 
    }
    elem = t->elem;
return elem;
}

list take (int n, list l){
    int contador = 0;
    Node *t; 
    Node *p;
    Node *j;
    t = l;
    while (t->next != NULL){
        contador++;
        t = t->next;
        j = j->next;
        if (contador > n){
            p = t;
            free(p);
        }
    }
    j->next = NULL;
return l;
}

list drop (int n, list l){
    int contador = 0;
    Node *p;

    while (contador != n){
        p = l;
        l = l->next;
        free(p);
        contador++;
    }
return l;
}

list copy_list(list l){
    list l2 = empty();
    Node *p, *q;
    p = l;
    if (p != NULL){
        l2 = malloc(sizeof(Node));
        l2->elem = l->elem;
        q = l2;
        while (p->next != NULL){
            q->next = malloc(sizeof(Node));
            q = q->next;
            p = p->next;
            q->elem = p->elem;
        }
        q->next = NULL;
    } else {
        l2 = NULL;
    }
return l2;    
}